﻿namespace Research.Member
{
    public class MemberConsts
    {
        public const string LocalizationSourceName = "Member";

        public const string ConnectionStringName = "Default";
    }
}