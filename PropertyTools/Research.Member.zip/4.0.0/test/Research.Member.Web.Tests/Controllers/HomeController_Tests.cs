﻿using System.Threading.Tasks;
using Research.Member.Web.Controllers;
using Shouldly;
using Xunit;

namespace Research.Member.Web.Tests.Controllers
{
    public class HomeController_Tests: MemberWebTestBase
    {
        [Fact]
        public async Task Index_Test()
        {
            //Act
            var response = await GetResponseAsStringAsync(
                GetUrl<HomeController>(nameof(HomeController.Index))
            );

            //Assert
            response.ShouldNotBeNullOrEmpty();
        }
    }
}
