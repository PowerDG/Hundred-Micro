using Research.Member.EntityFrameworkCore;

namespace Research.Member.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly MemberDbContext _context;

        public TestDataBuilder(MemberDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}