﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using Research.Member.EntityFrameworkCore;
using Research.Member.Tests.TestDatas;

namespace Research.Member.Tests
{
    public class MemberTestBase : AbpIntegratedTestBase<MemberTestModule>
    {
        public MemberTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<MemberDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<MemberDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<MemberDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<MemberDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<MemberDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<MemberDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<MemberDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<MemberDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}
