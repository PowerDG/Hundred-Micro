<template>
    <div>
        <Card dis-hover></Card>
    </div>
</template>
<script lang="ts">
import Vue from 'vue'
export default Vue.extend({
  
})
</script>

