export default class PageResult<T>{
    items:Array<T>;
    totalCount:number;
}