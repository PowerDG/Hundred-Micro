

namespace Research.Dtos
{
    public class PagedSortedAndFilteredInputDto : PagedAndSortedInputDto
    {
        public string FilterText { get; set; }



		 
		 
         

    }
}