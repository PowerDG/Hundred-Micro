﻿using Volo.Abp;

namespace Fooww.Research.EntityFrameworkCore
{
    public abstract class ResearchEntityFrameworkCoreTestBase : ResearchTestBase<ResearchEntityFrameworkCoreTestModule> 
    {

    }
}
