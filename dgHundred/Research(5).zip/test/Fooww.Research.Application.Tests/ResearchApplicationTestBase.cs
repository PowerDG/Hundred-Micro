﻿namespace Fooww.Research
{
    public abstract class ResearchApplicationTestBase : ResearchTestBase<ResearchApplicationTestModule> 
    {

    }
}
