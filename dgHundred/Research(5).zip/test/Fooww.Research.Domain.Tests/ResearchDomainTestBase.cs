﻿namespace Fooww.Research
{
    public abstract class ResearchDomainTestBase : ResearchTestBase<ResearchDomainTestModule> 
    {

    }
}
