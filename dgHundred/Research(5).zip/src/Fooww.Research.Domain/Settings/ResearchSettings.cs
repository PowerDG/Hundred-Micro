﻿namespace Fooww.Research.Settings
{
    public static class ResearchSettings
    {
        private const string Prefix = "Research";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}