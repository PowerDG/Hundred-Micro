﻿namespace Fooww.Research
{
    public static class ResearchConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
