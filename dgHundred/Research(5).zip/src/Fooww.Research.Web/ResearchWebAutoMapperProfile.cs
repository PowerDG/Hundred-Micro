﻿using AutoMapper;

namespace Fooww.Research.Web
{
    public class ResearchWebAutoMapperProfile : Profile
    {
        public ResearchWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
        }
    }
}
