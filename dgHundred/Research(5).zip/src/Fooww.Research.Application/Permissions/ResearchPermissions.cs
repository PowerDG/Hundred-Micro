﻿namespace Fooww.Research.Permissions
{
    public static class ResearchPermissions
    {
        public const string GroupName = "Research";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}