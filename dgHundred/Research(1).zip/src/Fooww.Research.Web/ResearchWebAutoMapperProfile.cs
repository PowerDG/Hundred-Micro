﻿using AutoMapper;

namespace Fooww.Research.Web
{
    public class ResearchWebAutoMapperProfile : Profile
    {
        public ResearchWebAutoMapperProfile()
        {
            /* You can configure your AutoMapper mapping configuration here.
             * Alternatively, you can split your mapping configurations
             * into multiple profile classes for a better organization. */
        }
    }
}