﻿namespace Fooww.Research
{
    public static class ResearchConsts
    {
        public const string DefaultDbTablePrefix = "Research";

        public const string DefaultDbSchema = null;
    }
}
