﻿namespace Fooww.Research.Settings
{
    public static class ResearchSettings
    {
        public const string GroupName = "Research";

        /* Add constants for setting names. Example:
         * public const string MySettingName = GroupName + ".MySettingName";
         */
    }
}