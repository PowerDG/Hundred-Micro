using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fooww.Research.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}