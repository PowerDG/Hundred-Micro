﻿using AutoMapper;

namespace Fooww.Research
{
    public class ResearchWebAutoMapperProfile : Profile
    {
        public ResearchWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
        }
    }
}
