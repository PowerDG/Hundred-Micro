using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace Fooww.Research.Pages
{
    public class IndexModel : AbpPageModel
    {
        public void OnGet()
        {
        }
    }
}