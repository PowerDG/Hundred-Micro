﻿using Volo.Abp.Settings;

namespace Fooww.Research.Settings
{
    public class ResearchSettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            /* Define module settings here.
             * Use names from ResearchSettings class.
             */
        }
    }
}