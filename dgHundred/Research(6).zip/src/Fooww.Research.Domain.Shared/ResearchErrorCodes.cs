﻿namespace Fooww.Research
{
    public static class ResearchErrorCodes
    {
        //Add your business exception error codes here...
    }
}
