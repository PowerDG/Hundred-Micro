﻿using Volo.Abp.Localization;

namespace Fooww.Research.Localization
{
    [LocalizationResourceName("Research")]
    public class ResearchResource
    {
        
    }
}
