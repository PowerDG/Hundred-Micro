﻿using System.Threading.Tasks;
using Xunit;

namespace Fooww.Research.Samples
{
    public class SampleManager_Tests : ResearchDomainTestBase
    {
        //private readonly SampleManager _sampleManager;

        public SampleManager_Tests()
        {
            //_sampleManager = GetRequiredService<SampleManager>();
        }

        [Fact]
        public async Task Method1Async()
        {

        }
    }
}
