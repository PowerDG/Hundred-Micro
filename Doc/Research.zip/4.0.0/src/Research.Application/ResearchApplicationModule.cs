﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace Research
{
    [DependsOn(
        typeof(ResearchCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class ResearchApplicationModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ResearchApplicationModule).GetAssembly());
        }
    }
}