﻿using Abp.Application.Services;

namespace Research
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class ResearchAppServiceBase : ApplicationService
    {
        protected ResearchAppServiceBase()
        {
            LocalizationSourceName = ResearchConsts.LocalizationSourceName;
        }
    }
}