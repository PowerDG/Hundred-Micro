﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Research.Configuration;
using Research.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace Research.Web.Startup
{
    [DependsOn(
        typeof(ResearchApplicationModule), 
        typeof(ResearchEntityFrameworkCoreModule), 
        typeof(AbpAspNetCoreModule))]
    public class ResearchWebModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public ResearchWebModule(IHostingEnvironment env)
        {
            _appConfiguration = AppConfigurations.Get(env.ContentRootPath, env.EnvironmentName);
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(ResearchConsts.ConnectionStringName);

            Configuration.Navigation.Providers.Add<ResearchNavigationProvider>();

            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(ResearchApplicationModule).GetAssembly()
                );
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ResearchWebModule).GetAssembly());
        }
    }
}