﻿using Abp.AspNetCore.Mvc.Views;

namespace Research.Web.Views
{
    public abstract class ResearchRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected ResearchRazorPage()
        {
            LocalizationSourceName = ResearchConsts.LocalizationSourceName;
        }
    }
}
