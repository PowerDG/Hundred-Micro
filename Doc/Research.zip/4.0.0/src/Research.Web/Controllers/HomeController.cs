using Microsoft.AspNetCore.Mvc;

namespace Research.Web.Controllers
{
    public class HomeController : ResearchControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}