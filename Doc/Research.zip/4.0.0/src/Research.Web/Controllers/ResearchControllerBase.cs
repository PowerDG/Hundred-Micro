using Abp.AspNetCore.Mvc.Controllers;

namespace Research.Web.Controllers
{
    public abstract class ResearchControllerBase: AbpController
    {
        protected ResearchControllerBase()
        {
            LocalizationSourceName = ResearchConsts.LocalizationSourceName;
        }
    }
}