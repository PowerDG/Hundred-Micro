namespace Research.Web.Controllers
{
    public class LayoutController : ResearchControllerBase
    {

    }
}