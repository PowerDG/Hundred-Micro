﻿using Abp.EntityFrameworkCore;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace Research.EntityFrameworkCore
{
    [DependsOn(
        typeof(ResearchCoreModule), 
        typeof(AbpEntityFrameworkCoreModule))]
    public class ResearchEntityFrameworkCoreModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ResearchEntityFrameworkCoreModule).GetAssembly());
        }
    }
}