﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Research.EntityFrameworkCore
{
    public class ResearchDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public ResearchDbContext(DbContextOptions<ResearchDbContext> options) 
            : base(options)
        {

        }
    }
}
