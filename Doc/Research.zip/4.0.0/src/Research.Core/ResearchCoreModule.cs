﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using Research.Localization;

namespace Research
{
    public class ResearchCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            ResearchLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ResearchCoreModule).GetAssembly());
        }
    }
}