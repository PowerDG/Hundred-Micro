using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Research.Web.Startup;
namespace Research.Web.Tests
{
    [DependsOn(
        typeof(ResearchWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class ResearchWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ResearchWebTestModule).GetAssembly());
        }
    }
}