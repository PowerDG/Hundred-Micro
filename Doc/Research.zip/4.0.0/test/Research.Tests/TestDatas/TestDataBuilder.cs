using Research.EntityFrameworkCore;

namespace Research.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly ResearchDbContext _context;

        public TestDataBuilder(ResearchDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}