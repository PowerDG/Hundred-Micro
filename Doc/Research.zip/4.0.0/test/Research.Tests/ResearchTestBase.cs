﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using Research.EntityFrameworkCore;
using Research.Tests.TestDatas;

namespace Research.Tests
{
    public class ResearchTestBase : AbpIntegratedTestBase<ResearchTestModule>
    {
        public ResearchTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<ResearchDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<ResearchDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<ResearchDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<ResearchDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<ResearchDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<ResearchDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<ResearchDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<ResearchDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}
